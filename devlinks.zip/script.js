const root = document.documentElement;
const toggle = document.getElementById("theme-toggle");

function setTheme(theme) {
  root.dataset.theme = theme;
  toggle.setAttribute("aria-checked", theme === "dark");
  localStorage.setItem("devlinks-theme", theme);
}

const saved = localStorage.getItem("devlinks-theme");
const prefersLight = window.matchMedia("(prefers-color-scheme: light)").matches;
setTheme(saved || (prefersLight ? "light" : "dark"));

toggle.addEventListener("click", () => {
  setTheme(root.dataset.theme === "dark" ? "light" : "dark");
});
